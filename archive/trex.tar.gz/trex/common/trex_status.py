#!/router/bin/python

# define the states in which a T-Rex can hold during its lifetime
# TRexStatus = Enum('TRexStatus', 'Idle Starting Running')

IDLE = 1
STARTING = 2
RUNNING = 3
